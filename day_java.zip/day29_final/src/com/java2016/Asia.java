package com.java2016;

public class Asia {
	public static final String SKIN_COLOR="黄色";  
	public static final int EYE_COUNT=2;
	public static final String EYE_COLOR="黑色";
}





/**
 * 使用final修饰过的都是不可改变的。
 * 1.final修饰变量
 * 	恒定不变的属性，可以使用final来修饰。
 * 	变量名建议全部使用大写。
 * 	final修饰的变量不能改变，如果在程序中重新赋值，编译报错
 * 2.final修饰方法
 * 	任何继承类无法覆盖该方法。重载不受影响。
 * 3.final修饰类
 * 	该类不能作为任何类的父类；类中的方法会全部被自动定义为final类型；
 */
