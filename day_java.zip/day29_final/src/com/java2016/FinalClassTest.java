package com.java2016;

public class FinalClassTest {
	
}
final class People{
	 
}
//class Teacher extends People{ //final 类无法被继承
	
//}