package com.java2016;

public class FinaMethodTest {

}
class Tree{
	public final void develop(){
		System.out.println("小树在成长");
	}
}

class Oak extends Tree{
	public Oak(){
		System.out.println("初始化橡树");
	}
	public void develop(String name){ //任何继承类无法覆盖该方法develop()。重载不受影响develop(String name)。
		
	}
}
