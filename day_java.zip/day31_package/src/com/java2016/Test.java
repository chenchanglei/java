package com.java2016;

public class Test {
	public static void main(String[] args){
		Student stu=new Student();
		stu.setAddr("asf");
		System.out.println(stu.getAddr());
		stu.setAge(23);
		System.out.println(stu.getAge());
	}
}
