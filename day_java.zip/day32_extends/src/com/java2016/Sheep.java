package com.java2016;

public class Sheep {
	public void eat(){//重写了Animal类的eat方法
		System.out.println("山羊在吃草");
	}
	public void fire(){//自有方法
		System.out.println("山羊在打架");
	}
}
