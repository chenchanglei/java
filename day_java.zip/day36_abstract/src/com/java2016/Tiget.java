package com.java2016;

public class Tiget extends Feline{
	public void catchAnimal(Animal animal){
		System.out.println("老虎在捕食");
	}
	
}
