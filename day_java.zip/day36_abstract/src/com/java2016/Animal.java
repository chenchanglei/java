package com.java2016;

public class Animal {

}
