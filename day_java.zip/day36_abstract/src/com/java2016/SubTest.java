package com.java2016;

public class SubTest extends Test {
	@Override
	public void test1(){
		
	}
	public void test2(){
		
	}
	
}
