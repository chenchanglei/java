package com.java2016;

public abstract class Test {
	public abstract void test1();
	public abstract void test2();
	public void test3(){
		
	}
}
