package com.java2016;

public class Mouse extends Animal{

}
