package com.java2016;

public class Tiger extends Animal{
	public void showMe(){
		System.out.println("我是老虎");
	}
}
