package com.java2016;

public class Cat extends Animal{
	public void showMe(){
		System.out.println("我是猫");
	}
}
