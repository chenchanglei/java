package com.java2016;

public class Animal {
	public void showMe(){
		System.out.println("我是动物");
	}
}
