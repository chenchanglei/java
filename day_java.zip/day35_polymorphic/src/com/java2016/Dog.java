package com.java2016;

public class Dog extends Animal{
	public void showMe(){
		System.out.println("我是狗");
	}
}
