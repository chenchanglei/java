package com.java2016;

public class Chinese extends People {
	
	
	public void speakChinese(){
		System.out.println("中国人说汉语");
	}
}
