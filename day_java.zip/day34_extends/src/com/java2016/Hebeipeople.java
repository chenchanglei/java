package com.java2016;

public class Hebeipeople extends Chinese{
	public void speakHebeiLang(){
		System.out.println("河北人说河北方言");
	}
}
