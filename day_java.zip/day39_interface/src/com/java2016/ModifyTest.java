package com.java2016;

public class ModifyTest {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Modifier2 m=new Modifier2();
//		Modifier m=new Modifier2();
		m.print();
		m.print1();
		m.print2();
		m.print3();
		m.print4();
	}

}
