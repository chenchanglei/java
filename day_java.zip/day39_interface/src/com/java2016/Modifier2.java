package com.java2016;

public class Modifier2 implements Modifier {

	@Override
	public void print() {
		// TODO Auto-generated method stub
		System.out.println("void");
	}

	@Override
	public void print1() {
		// TODO Auto-generated method stub
		System.out.println("public void");
	}

	@Override
	public void print2() {
		// TODO Auto-generated method stub
		System.out.println("abstract void ");

	}

	@Override
	public void print3() {
		// TODO Auto-generated method stub
		System.out.println("abstract public void");

	}

	@Override
	public void print4() {
		// TODO Auto-generated method stub
		System.out.println("public abstract void");

	}

}
