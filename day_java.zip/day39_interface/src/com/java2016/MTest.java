package com.java2016;

public class MTest implements Jia,Jian,Cheng,Chu {


	@Override
	public int jia(int a, int b) {
		// TODO Auto-generated method stub
		return a+b;
	}
	public int jian(int a, int b) {
		// TODO Auto-generated method stub
		return a-b;
	}
	public int cheng(int a, int b) {
		// TODO Auto-generated method stub
		return a*b;
	}
	public int chu(int a, int b) {
		// TODO Auto-generated method stub
		return a/b;
	}

}
