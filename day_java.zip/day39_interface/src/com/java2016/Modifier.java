package com.java2016;

public interface Modifier {
	void print();
	public void print1();
	abstract void print2();
	abstract public void print3();
	public abstract void print4();
}
