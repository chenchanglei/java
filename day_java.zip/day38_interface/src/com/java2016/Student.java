package com.java2016;

public interface Student {
	int banji=1201;	
	String name="小明";
	abstract void learn(); //默认会增加abstract ，这是手动加上
	void eat();
	void sleep();
	
}
