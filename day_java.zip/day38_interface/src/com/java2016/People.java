package com.java2016;

public interface People {
	String name="老王";
	abstract void learn(); //默认会增加abstract ，这是手动加上
	void eat();
	void sleep();
}
