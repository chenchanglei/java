package com.java2016;

public class Test {
	public static void main(String[] args){
		C c=new C();
		C c1=new C(1);
	}
}


/**
*调用A的无参构造方法
*调用B的无参构造方法
*调用C的无参构造方法
*调用A的无参构造方法
*调用B的有参构造方法
*调用C的有参构造方法
*/